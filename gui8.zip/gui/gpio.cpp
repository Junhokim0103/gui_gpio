#include <gpiod.h>

int setGpio2(bool value)
{
    const char *chipname = "gpiochip5";
    int line_num = 10;

    gpiod_chip *chip = gpiod_chip_open_by_name(chipname);
    if (!chip) return -1;

    gpiod_line *line = gpiod_chip_get_line(chip, line_num);
    if (!line) {
        gpiod_chip_close(chip);
        return -1;
    }

    if (gpiod_line_request_output(line, "qt_app", 1) < 0) {
        gpiod_chip_close(chip);
        return -1;
    }
    if(value == true)
    {
       gpiod_line_set_value(line, 1);  // HIGH
    }else{
       gpiod_line_set_value(line, 0);  // HIGH
    }

    gpiod_line_release(line);
    gpiod_chip_close(chip);

    return 0;
}
