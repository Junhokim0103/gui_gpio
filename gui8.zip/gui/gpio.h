#ifndef GPIO_H
#define GPIO_H


int setGpio2(bool value);
#endif // GPIO_H
