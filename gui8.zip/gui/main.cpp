#include "mainwindow.h"

#include <QApplication>
//QT += core gui widgets svg serialbus
//PKGCONFIG += libgpiod
//CONFIG += link_pkgconfig
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();
    return a.exec();
}
