#!/bin/sh
/home/kim/stm32mpu135work/buildroot/output/host/bin/qmake -o Makefile gui.pro


