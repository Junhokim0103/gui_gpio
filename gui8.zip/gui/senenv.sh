#!/bin/sh
export SYSROOT=/home/kim/stm32mpu135work/buildroot/output/host/arm-buildroot-linux-gnueabihf/sysroot
export PATH=/home/kim/stm32mpu135work/buildroot/output/host/bin:$PATH
export CROSS_COMPILE=arm-linux-
